import os

os.system("ssh root@10.10.10.44 yum install nasm")

