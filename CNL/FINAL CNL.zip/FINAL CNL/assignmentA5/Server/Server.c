// server code for UDP socket programming
#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
 
#define IP_PROTOCOL 0
#define PORT_NO 15050
#define sendrecvflag 0
#define nofile "File Not Found!"
 
// driver code
int main()
{
    int sockfd, nBytes;
    struct sockaddr_in addr_con;
    int addrlen = sizeof(addr_con);
    addr_con.sin_family = AF_INET;
    addr_con.sin_port = htons(PORT_NO);
    addr_con.sin_addr.s_addr = INADDR_ANY;
    
    FILE* fp;
 
    // socket()
    sockfd = socket(AF_INET, SOCK_DGRAM, IP_PROTOCOL);
 
    if (sockfd < 0)
        printf("\nfile descriptor not received!!\n");
    else
        printf("\nfile descriptor %d received\n", sockfd);
 
    // bind()
    if (bind(sockfd, (struct sockaddr*)&addr_con, sizeof(addr_con)) == 0)
        printf("\nSuccessfully binded!\n");
    else
        printf("\nBinding Failed!\n");
 
        printf("\nWaiting for file name...\n");
 
        // receive file name
        char filename[50];
        //clearBuf(net_buf);
 
        nBytes = recvfrom(sockfd, filename,
                         50, sendrecvflag,
                          (struct sockaddr*)&addr_con, &addrlen);
 
        fp = fopen(filename, "rb");
        printf("\nFile Name Received: %s\n", filename);
        
        if (fp == NULL)
            printf("\nFile open failed!\n");
        else
            printf("\nFile Successfully opened!\n");
 
          // send
          
          fseek(fp, 0, SEEK_END); 
          long int size=ftell(fp);
          fseek(fp,0,SEEK_SET);
         
	char file[size];
    	fread(file,size,1,fp);
    	sendto(sockfd, (void*)&size, sizeof(size),
                   sendrecvflag,
                (struct sockaddr*)&addr_con, addrlen);
	
            sendto(sockfd, file, size,
                   sendrecvflag,
                (struct sockaddr*)&addr_con, addrlen);
           
        if (fp != NULL)
            fclose(fp);
    return 0;
}
