// client code for UDP socket programming
#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
 
#define IP_PROTOCOL 0
#define IP_ADDRESS "127.0.0.1" // localhost
#define PORT_NO 15050

#define sendrecvflag 0
 
 
// driver code
int main()
{
    int sockfd, nBytes;
    struct sockaddr_in addr_con;
    int addrlen = sizeof(addr_con);
    addr_con.sin_family = AF_INET;
    addr_con.sin_port = htons(PORT_NO);
    addr_con.sin_addr.s_addr = inet_addr(IP_ADDRESS);

    FILE* fp;
 
    // socket()
    sockfd = socket(AF_INET, SOCK_DGRAM,
                    IP_PROTOCOL);
 	char filename[50];
    if (sockfd < 0)
        printf("\nfile descriptor not received!!\n");
    else
        printf("\nfile descriptor %d received\n", sockfd);
        printf("\nPlease enter file name to receive:\n");
        scanf("%s", filename);
        sendto(sockfd, filename, 50,
               sendrecvflag, (struct sockaddr*)&addr_con,
               addrlen);
 
 	fp=fopen(filename,"wb+");
 	
        
 	
 	long int size;
 	nBytes = recvfrom(sockfd, (void*)&size, sizeof(size),
                              sendrecvflag, (struct sockaddr*)&addr_con,
                              &addrlen);
	printf("\n size==%ld\n",size);
 	char file[size];
 	
        
            nBytes = recvfrom(sockfd, file,size,
                              sendrecvflag, (struct sockaddr*)&addr_con,
                              &addrlen);
	printf("\n-------------------------------\n");
        
        fwrite(file,size,1,fp);
        printf("\nTRANSFER COMPLETE\n");
        
        printf("\n-------------------------------\n");
        fclose(fp);
    return 0;
}
