//Accepts single character as input convert it to 7 bit dataword which is then transmitted

#include<bits/stdc++.h>
using namespace std;
class Sender
{
	bool dataword[12];			//for 7 bit total codeword=11 for simplicity 1-11 so 12 		
	bool bit_or_parity[12];			//0-parity 1-data
	char a;
	bool parity;				//0-even 1-odd
	friend class Receiver;
	public:
	Sender()
	{
		int ctr=0;
		for(int i=1;i<12;i++)
		{
			dataword[i]=0;
			if(i==pow(2,ctr))
			{
				bit_or_parity[i]=0;
				ctr++;
			}
			else
			{
				bit_or_parity[i]=1;
			}
			
		}
		/*cout<<"\nbit or parity array\n";
		for(int i=11;i>=1;i--)
		{
			cout<<bit_or_parity[i];
		}*/
	}
	void getData()
	{
		cout<<"\nDataword format==";
		cout<<"\nD7 D6 D5 D4 D3 D2 D1";
		char ans;
		cout<<"\nDo you want to agree on even parity(y/n)==";
		cin>>ans;
		if(ans=='Y' || ans=='y')
		{
			cout<<"\nEven Parity agreed";
			parity=0;
			
		}
		else
		{
			cout<<"\nOdd Parity agreed";
			parity=1;
		}
		cout<<"\nenter a single character==";
		cin>>a;
		int b=int(a);

		string binary = std::bitset<7>(b).to_string(); //to binary
    		cout<<"\nDecimal equivalent=="<<b<<"\nBinary equivalent=="<<binary<<"\n";
    		bool temp[8];
		for(int i=7,j=0;i>=1,j<7;i--,j++)
		{
			temp[i]=bool(binary[j]-48);
		}
		int x=7;
		for(int i=11;i>0;i--)
		{
			if(bit_or_parity[i])
			{
				dataword[i]=temp[x];
				x--;
			}
		}
	}
	void display()
	{
		cout<<"\ncodeword==";
		cout<<"\n11 10  9  8  7  6  5  4  3  2  1";
		cout<<"\nD7 D6 D5 P8 D4 D3 D2 P4 D1 P2 P1\n";

		for(int i=11;i>=1;i--)
		{
			cout<<dataword[i]<<"  ";
		}
		cout<<endl;
		
	}
	void findParity()
	{
		int ctr=0;
		cout<<"\nParity bits";
		if(parity)
		{
			cout<<" (Odd parity)";
		}
		else
		{
			cout<<" (Even parity)";
		}
		for(int i=1;i<12;i=pow(2,ctr))
		{
			int even_count=0;
			for(int j=i+1;j<12;j++)
			{
				if(j&(1<<ctr))
				{
					if(dataword[j])
					{
						even_count++;
					}
				}
				
				
			
			}
			if(parity==0)
			{
				if(even_count%2)
				{
					dataword[i]=1;
					
				}
				else
				{
					dataword[i]=0;
				}
			}
			else
			{	
				if(even_count%2==0)	
				{
					dataword[i]=1;
				}
				else
				{
					dataword[i]=0;
				}
			}				
				cout<<"\nP"<<i<<"=="<<dataword[i];
			ctr++;
			
		}
	}
	bool* sendData()
	{
		bool old_dataword[12];
		for(int i=1;i<12;i++)
			{
				old_dataword[i]=dataword[i];
			}
		cout<<"\nReady for transmission..";
		cout<<"\ndo you want to alter any bit?(y/n)==";
		char ans;
		cin>>ans;
		if(ans=='y' || ans=='Y')
		{
			
			
			cout<<"\nEnter position of bit you want to alter(you can alter parity bit or data bit) range 1-11==";
			int pos;
			cin>>pos;
			if(pos>=1 && pos<=11)
			{
				dataword[pos]=!(dataword[pos]);
				cout<<"\nBit reverted!!";
			}
			else
			{
				cout<<"\nWrong position entered dataword not changed!";
			}
			cout<<"\nOld codeword(without alteration)==";
			for(int i=11;i>=1;i--)
			{
				cout<<old_dataword[i];
			}
		}
		cout<<"\n**************SUMMARY************";
		cout<<"\nDataword to be transmitted==";
		int ctr=3;
		for(int i=11;i>0;i--)
		{
			if(i==pow(2,ctr))
			{
				ctr--;
			}
			else
			{	
				cout<<old_dataword[i];
			
			}
		
			
		}
		cout<<"\nCodeword transmitted==";
		for(int i=11;i>=1;i--)
		{
			cout<<dataword[i];
		}
		cout<<endl;

		
		
		return dataword;
	}
};
class Receiver
{	
	Sender s;
	public:
	Receiver(Sender &s1)
	{
		
		s=s1;
		
	}
	void check()
	{
		bool *received_codeword;
		received_codeword=s.sendData();
		bool parity[4];
		for(int i=0;i<4;i++)
		{
			parity[i]=0;
		}
		int ctr=0;
		bool is_error=0;
		for(int i=1;i<12;i=pow(2,ctr))
		{
			int even_count=0;
			for(int j=i;j<12;j++)
			{
				if(j&(1<<ctr))
				{
					if(received_codeword[j])
					{
						even_count++;
					}
				}
				
				
			
			}
			if(even_count%2)
				{
					
					is_error=1;
					parity[ctr]=1;
					
				}
				
			ctr++;
			
		}
		cout<<"\n*******************RECEIVER END*************************";
		cout<<"\nReceived Codeword==";
		for(int i=11;i>=1;i--)
		{
			cout<<received_codeword[i];
		}
		cout<<endl;


		if(is_error)
		{
			int error=0;
			for(int i=0;i<4;i++)
			{
				error+=parity[i]*pow(2,i);
			}
			cout<<"\nError at position=="<<error;
			
			received_codeword[error]=!(received_codeword[error]);
			cout<<"\nError correction successful!";
		}
		else
		{
			cout<<"\nNo error!!";
			cout<<"\nNo correction required";
		}
		cout<<"\nCodeword after error correction (if any)==";
		for(int i=11;i>=1;i--)
		{
			cout<<received_codeword[i];
		}
		cout<<endl;
		cout<<"\nExtracting dataword...";
		cout<<"\nDataword received==";
		ctr=3;
		int temp=6;
		int received=0;
		for(int i=11;i>0;i--)
		{
			if(i==pow(2,ctr))
			{
				ctr--;
			}
			else
			{	
				cout<<received_codeword[i];
				received+=received_codeword[i]*pow(2,temp);
				temp--;			
			}
		
			
		}
		cout<<endl;
		
		cout<<"\nReceived character=="<<char(received)<<endl;

	}
	
	
};
int main()
{
	
	Sender s1;
	cout<<"\n*******************SENDER END*************************";
	s1.getData();
	s1.findParity();
	s1.display();
	
	Receiver r1(s1);
	r1.check();
}


	

