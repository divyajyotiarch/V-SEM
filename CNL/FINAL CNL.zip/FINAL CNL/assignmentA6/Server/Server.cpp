// Server side C/C++ program to demonstrate Socket programming
#include<sstream>
#include <unistd.h>
#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include<iostream>
#include<fstream>
#include<math.h>
using namespace std;
#define PORT 8081
  double pi=3.1415926535;
void clearBuf(char *buf)
{
	for(int i=0;i<1024;i++)
    	    buf[i] = '\0';
}
void menu(int new_socket,char* buffer)
{
	int mno;
	ostringstream ss;
	char *ang = (char *)malloc(128);
	char* ans;
	cout<<"\nreading angle...";
	int valread = read( new_socket , buffer, 1024);
	double angle;
	
	mno=buffer[0]-48;
	int i;
	for(i=0;i<strlen(buffer)-1;i++)
	{
		ang[i]=buffer[i+1];	
	}
	ang[i]='\0';
	angle=atof(ang);
	printf("\nangle:%f",angle);
	

	switch(mno)
	{
		case 1:
			{
				

				ss << sin(angle*pi/180);
				string s(ss.str());
				cout<<"\nans=="<<s;
				ans=&s[0];
				break;
			}
		case 2:
			{
				
				ss << cos(angle*pi/180);
				string s(ss.str());
				cout<<"\nans=="<<s;
				ans=&s[0];
				break;
			}
		case 3:
			{
				ss << tan(angle*pi/180);
				string s(ss.str());
				cout<<"\nans=="<<s;
				ans=&s[0];	
				break;
			}
		case 4:
			{
				
				ss << (1/sin(angle*pi/180));
				string s(ss.str());
				cout<<"\nans=="<<s;
				ans=&s[0];
				break;
			}
		case 5:
			{
				
				ss << (1/cos(angle*pi/180));
				string s(ss.str());
				cout<<"\nans=="<<s;
				ans=&s[0];
				break;
			}
		case 6:
			{
				
				ss << (1/tan(angle*pi/180));
				string s(ss.str());
				cout<<"\nans=="<<s;
				ans=&s[0];
				break;
			}

	}

    send(new_socket , ans ,strlen(ans) , 0 );
    printf("\nAnswer sent to client machine\n");
 
	
}
int main(int argc, char const *argv[])
{
    int server_fd, new_socket, valread;
    struct sockaddr_in address;
    int opt = 1;
    int addrlen = sizeof(address);
    char buffer[1024] = {0};
    //char *hello = "Hello from server";
      
    // Creating socket file descriptor
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0)
    {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }
      
    // Forcefully attaching socket to the port 8080
   /* if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,
                                                  &opt, sizeof(opt)))
    {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }*/
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons( PORT );
    
    cout<<"\n SERVER Started";
      
    // Forcefully attaching socket to the port 8080
    if (bind(server_fd, (struct sockaddr *)&address, 
                                 sizeof(address))<0)
    {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }
    if (listen(server_fd, 3) < 0)
    {
        perror("listen");
        exit(EXIT_FAILURE);
    }
    if ((new_socket = accept(server_fd, (struct sockaddr *)&address, 
                       (socklen_t*)&addrlen))<0)
    {
        perror("accept");
        exit(EXIT_FAILURE);
    }
    valread = read( new_socket , buffer, 1024);
    printf("\nMessage received:%s\n",buffer);
    string msg;
    cout<<"\nEnter ur msg:";
    cin>>msg;
    char* servmsg=&msg[0];
    send(new_socket , servmsg ,strlen(servmsg) , 0 );
    printf("\nmessage sent");
 
 
 	cout<<"\n waiting for file name";
 	clearBuf(buffer);
 	valread = read( new_socket , buffer, 1024);
    printf("\nFilename received:%s",buffer );
    
    
 
 	//clearBuf(buffer);
 //file
 	
 	ifstream in;
    in.open(buffer,ios::in);
    string data;
    while(in)
    {
    	string tempData;
    	getline(in, tempData);
    	tempData += '\n';
    	data += tempData;
    }
    in>>data;
    char *msgFile = &data[0];
    cout<<"\n************* File contents***********";
    cout<<data;
    send(new_socket , msgFile , strlen(msgFile) , 0 );
	//printf("\n%s\n",buffer );
 
 	in.close();
 
	cout<<"\n******************CALCULATOR*******************";
	menu(new_socket,buffer);
    return 0;
}
