// Client side C/C++ program to demonstrate Socket programming
#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include<arpa/inet.h>
#include <unistd.h>
#include<iostream>
#include<fstream>
using namespace std;
#define PORT 8081

  double pi=3.1415926535;
  
void clearBuf(char *buf)
{
	for(int i=0;i<1024;i++)
    	    buf[i] = '\0';
}
void menu(int sock,char* buffer)
{
	int mno;
	clearBuf(buffer);
	cout<<"\n*****************MENU*********";
	cout<<"\n1.sine\n2.cosine\n3.tangent\n4.cosecant\n5.secant\n6.cotangent";
	cout<<"\n enter menu no==";
	cin>>mno;
	cout<<"\n enter angle==";
	string angle;
	cin>>angle;
	for(int i=0;i<angle.length();i++)
	{
		buffer[i+1]=angle[i];	
	}
	
	switch(mno)
	{
		case 1:
			{
				
				buffer[0]=char('1');
				send(sock , buffer , strlen(buffer) , 0 );
				printf("\nangle sent to server");
    
				break;
			}
		case 2:
			{
				
				buffer[0]=char('2');
				send(sock , buffer , strlen(buffer) , 0 );
				printf("\nangle sent to server");
    
				break;
			}
		case 3:
			{
				
				buffer[0]=char('3');
				send(sock , buffer , strlen(buffer) , 0 );
				printf("\nangle sent to server");
    
				break;
			}
		case 4:
			{
				
				buffer[0]=char('4');
				send(sock , buffer , strlen(buffer) , 0 );
				printf("\nangle sent to server");
    
				break;
			}
		case 5:
			{
				
				buffer[0]=char('5');
				send(sock , buffer , strlen(buffer) , 0 );
				printf("\nangle sent to server");
    
				break;
			}
		case 6:
			{
				
				buffer[0]=char('6');
				send(sock , buffer , strlen(buffer) , 0 );
				printf("\nangle sent to server");
    
				break;
			}

	}
	clearBuf(buffer);
	int valread = read( sock , buffer, 1024);
    printf("\nAnswer received:%s\n",buffer );
	
}
int main(int argc, char const *argv[])
{
    struct sockaddr_in address;
    int sock = 0, valread;
    struct sockaddr_in serv_addr;
   // char *hello = "Hello from client";
    char buffer[1024] = {0};
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        printf("\n Socket creation error \n");
        return -1;
    }
  
    memset(&serv_addr, '0', sizeof(serv_addr));
  
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
      
    // Convert IPv4 and IPv6 addresses from text to binary form
    if(inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr)<=0) 
    {
        printf("\nInvalid address/ Address not supported \n");
        return -1;
    }
  
    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
    {
        printf("\nConnection Failed \n");
        return -1;
    }
    //string msg;
    char msg[1024]; 	
    cout<<"\n Enter ur message:";
    //cin>>msg;
    scanf("%s", msg);
    //char* clientmsg=&msg[0];
    send(sock , msg , strlen(msg) , 0 );
    //send(sock , clientmsg , strlen(clientmsg) , 0 );
    printf("\nmessage sent");
    valread = read( sock , buffer, 1024);
    printf("\nReceived msg:%s\n",buffer );
   
    cout<<"\n********************FILE TRANSFER****************";
    cout<<"\nEnter file name=";
    cin>>msg;
    char* fname=&msg[0];

    send(sock , fname , strlen(fname) , 0 );
    
    
    clearBuf(buffer);
    valread = read( sock , buffer, 1024);
    ofstream out;
    out.open(msg);
    string data;
    int i=0;
    out<<buffer;
    
    
    printf("\nReceived file contents:%s\n",buffer );
    out.close();
    
    cout<<"\n******************CALCULATOR*******************";
	menu(sock,buffer);
    
    
    
    return 0;
}
